package com.example.courierapp;

public class Constants {
    public static String KEY_EMAIL = "email";
    public static String KEY_PASSWORD = "password";
}
